import openai
from flask import Flask, request, render_template
from youtube_transcript_api import YouTubeTranscriptApi

# Set your OpenAI API key
openai.api_key = "Enter Open Ai key Here"

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def summarize_video():
    if request.method == 'POST':
        video_url = request.form['video_url']
        video_url_parts = video_url.split('/')
        video_code = video_url_parts[3]

        srt = YouTubeTranscriptApi.get_transcript(video_code)
        captions = " ".join([x['text'] for x in srt])

        custom_prompt = '''I will provide you with captions of a video, I want you to generate point summary of it.
        Important Rules: 1. You should be discreet about using captions 2. the 10 points should immersive yet they should not be long 3. the result should be engaging and human like 4. Each new summary should start with a new line. the captions are: '''



        full_prompt = custom_prompt + captions

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a summarizer."},
                {"role": "user", "content": full_prompt},
            ]
        )

        summary = response['choices'][0]['message']['content']

        return render_template('result.html',)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
