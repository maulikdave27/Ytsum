import openai

from youtube_transcript_api import YouTubeTranscriptApi
# Set your OpenAI API key
openai.api_key = "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"

video_url = input('video_url: ')
video_url_parts = video_url.split('/')
video_code = video_url_parts[3]


srt = YouTubeTranscriptApi.get_transcript(video_code)

captions= " ".join([x['text'] for x in srt])
    #return captions
    
#custom_prompt='''Imagine you are a summarizer to which if provided the captions of a YouTube video, it will generate a point summary out of it. Do not use difficult English as you will be used by a lot of people who may not have a great vocabulary. The goal is to create such a good summary that it is equivalent to watching the video itself. Start with a small intro to what's happening in the video based on the captions provided and then create a point-to-point detailed summary of what happened in the video. Note that the introduction should not be considered a point. Also, do not tell the user that you are using captions. In the end, provide a conclusion. The points should be clearly marked by adding '@' character at the end of each point, and also after the small introduction '@' should be added so as to get proper answer and demarcation if '@' is not there at the end of each point. After the introduction ends, do not number the points, and remember to add '@' after each point and introduction. The user should not know that we are using captions of the video, so therefore do not provide any disclaimer or note. Here is the captions of the video itself:'''
custom_prompt = '''You embody a summarizer with the extraordinary ability to craft a comprehensive point-by-point summary solely from the captions of a YouTube video. Your ultimate objective is to construct a summary that mirrors the immersive experience of watching the video itself.

Commence by delivering a succinct introduction to the video's content, drawing inspiration exclusively from the provided captions. Following this introduction, furnish a meticulous point-by-point summary encompassing the video's pivotal details. Each section, including the introduction, must be distinctly marked with '@' for clarity.

Maintain absolute discretion regarding the source of information (captions). Finally, elegantly conclude the summary, and again, use '@' to demarcate it from the preceding sections.

Below, you'll find the captions extracted from the video:
'''

full_prompt = custom_prompt + captions
    

response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a summarizer."},
        {"role": "user", "content": full_prompt},
    ]
)

summary = response['choices'][0]['message']['content']
summary1=summary.split('@')
for i in summary1:
    print(i)